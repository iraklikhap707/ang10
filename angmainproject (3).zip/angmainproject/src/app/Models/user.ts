export class User{
id?: number;
email!:string;
first_name!:string;
last_name!:string;
avatar!:string;
name: any;
description: any;
image: any;
}