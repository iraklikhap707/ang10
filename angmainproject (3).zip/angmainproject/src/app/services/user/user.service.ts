import { Injectable } from '@angular/core';
import { ApiService } from '../api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  getproduct() {
    throw new Error('Method not implemented.');
  }
  constructor(private http: ApiService) {}

  getproducs() {
    return this.http['getApi']("https://restaurant.stepprojects.ge/api/Products/GetAll");
  }

  Basket(productId: number, quantity: number = 1): Observable<any> {
    const body = {
      productId: productId,
      quantity: quantity
    };
    return this.http['postApi']("https://restaurant.stepprojects.ge/api/Baskets/AddToBasket", body);
  }

  updateBasket(productId: number, quantity: number = 1): Observable<any> {
    const body = {
      productId: productId,
      quantity: quantity
    };
    return this.http['putApi']("https://restaurant.stepprojects.ge/api/Baskets/UpdateBasket", body);
  }

  deleteFromBasket(productId: number): Observable<any> {
    return this.http['deleteApi'](`https://restaurant.stepprojects.ge/api/Baskets/DeleteProduct/${productId}`);
  }
}
