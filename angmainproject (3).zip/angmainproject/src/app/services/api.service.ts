import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  delete(arg0: string) {
    throw new Error('Method not implemented.');
  }
  constructor(private http: HttpClient) {}

  getApi(url: string): Observable<any> {
    return this.http.get<any>(url);
  }

  postApi(url: string, body: any): Observable<any> {
    return this.http.post<any>(url, body);
  }

  putApi(url: string, body: any): Observable<any> {
    return this.http.put<any>(url, body);
  }

  deleteApi(url: string): Observable<any> {
    return this.http.delete<any>(url);
  }
}
