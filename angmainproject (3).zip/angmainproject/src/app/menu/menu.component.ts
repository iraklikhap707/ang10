import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { UserService } from '../services/user/user.service';
import { RouterLink } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-menu', 
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
  standalone: true,
  imports: [CommonModule, HttpClientModule]
})
export class MenuComponent implements OnInit {
  items: any[] = [];

  constructor(
    private userService: UserService,
    private basketService: ApiService
  ) {}

  ngOnInit() {
    this.userService.getproducs().subscribe({
      next: (resp: any[]) => {
        console.log('პროდუქტები:', resp);
        this.items = resp;
      },
      error: (err: any) => {
        console.error('პროდუქტების წაღების შეცდომა:', err);
      }
    });
  }

  addToBasket(item: any) {
    const body = {
      productId: item.id,
      quantity: 1
    };

    this.basketService['postApi']('https://restaurant.stepprojects.ge/api/Baskets/AddToBasket', body).subscribe({
      next: (res: any) => console.log('დაემატა კალათაში:', res),
      error: (err: any) => console.error('დამატების შეცდომა:', err)
    });
  }

  updateBasket(item: any) {
    const body = {
      productId: item.id,
      quantity: item.quantity || 1
    };

    this.basketService['putApi']('https://restaurant.stepprojects.ge/api/Baskets/UpdateBasket', body).subscribe({
      next: (res: any) => console.log('განახლდა კალათა:', res),
      error: (err: any) => console.error('განახლების შეცდომა:', err)
    });
  }

  deleteFromBasket(id: number) {
    this.basketService['deleteApi'](`https://restaurant.stepprojects.ge/api/Baskets/DeleteProduct/${id}`).subscribe({
      next: (res: any) => console.log('წაიშალა პროდუქტიდან:', res),
      error: (err: any) => console.error('წაშლის შეცდომა:', err)
    });
  }
}
